/**
 * 
 */
/**
 * @author navne
 *
 */
module Pranay_CC_LoanManagement {
	requires java.sql;
}